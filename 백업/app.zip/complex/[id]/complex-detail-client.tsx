'use client'

import { useMemo, useState } from 'react'
import Link from 'next/link'
import PriceChart from './price-chart'
import NaverMap from '@/components/NaverMap'

type Complex = {
  id?: string | number
  official_name?: string | null
  road_name?: string | null
  road_bonbun?: string | null
  road_bubun?: string | null
  umd_name?: string | null
  build_year?: number | null
  sido_name?: string | null
  sigungu_name?: string | null
}

type Transaction = {
  id?: string | number
  complex_id?: string | null
  apartment_name?: string | null
  price_krw?: number | null
  area_m2?: number | null
  floor?: number | null
  deal_year?: number | null
  deal_month?: number | null
  deal_day?: number | null
  lawd_code?: string | null
  dong?: string | null
  umd_name?: string | null
}

function formatKoreanPrice(value: number) {
  const eok = Math.floor(value / 10000)
  const man = value % 10000

  if (eok > 0 && man > 0) return `${eok}억 ${man.toLocaleString()}만원`
  if (eok > 0) return `${eok}억원`
  return `${man.toLocaleString()}만원`
}

function formatRoadAddress(complex: Complex) {
  const head = [complex.sido_name, complex.sigungu_name, complex.road_name]
    .filter(Boolean)
    .join(' ')

  const roadNameOnly = String(complex.road_name || '').trim()
  const bonbun = String(complex.road_bonbun || '').trim()
  const bubun = String(complex.road_bubun || '').trim()
  const base = head || roadNameOnly

  if (!base) return ''

  if (bonbun && bubun && bubun !== '0' && bubun !== '0000') {
    return `${base} ${Number(bonbun)}-${Number(bubun)}`
  }

  if (bonbun) {
    return `${base} ${Number(bonbun)}`
  }

  return base
}

function formatJibunAddress(complex: Complex) {
  return [complex.sido_name, complex.sigungu_name, complex.umd_name]
    .filter(Boolean)
    .join(' ')
}

function formatBuildText(buildYear?: number | null) {
  if (!buildYear) return ''
  const currentYear = new Date().getFullYear()
  return `${currentYear - buildYear}년차 ${buildYear}년 준공`
}

function formatDealDate(item: Transaction) {
  return `${item.deal_year}.${String(item.deal_month || '').padStart(2, '0')}.${String(item.deal_day || '').padStart(2, '0')}`
}

export default function ComplexDetailClient({
  complex,
  transactions,
}: {
  complex: Complex
  transactions: Transaction[]
}) {
  const [selectedArea, setSelectedArea] = useState<number | null>(null)

  const safeTransactions = transactions || []
  const dealCount = safeTransactions.length

  const prices = safeTransactions
    .map((item) => Number(item.price_krw || 0))
    .filter((price) => price > 0)

  const maxPrice = prices.length ? Math.max(...prices) : 0
  const minPrice = prices.length ? Math.min(...prices) : 0
  const latestPrice = safeTransactions.length
    ? Number(safeTransactions[0]?.price_krw || 0)
    : 0

  const areaList = useMemo(() => {
    const map = new Map<number, number>()

    for (const item of safeTransactions) {
      const area = Math.round(Number(item.area_m2 || 0))
      if (!area) continue
      map.set(area, (map.get(area) || 0) + 1)
    }

    return Array.from(map.entries())
      .map(([area, count]) => ({ area, count }))
      .sort((a, b) => a.area - b.area)
  }, [safeTransactions])

  const filteredTransactions = useMemo(() => {
    if (selectedArea === null) return safeTransactions
    return safeTransactions.filter((item) => {
      const area = Math.round(Number(item.area_m2 || 0))
      return area === selectedArea
    })
  }, [safeTransactions, selectedArea])

  const chartData = useMemo(() => {
    return filteredTransactions
      .slice()
      .sort((a, b) => {
        const dateA = new Date(
          `${a.deal_year}-${String(a.deal_month).padStart(2, '0')}-${String(a.deal_day).padStart(2, '0')}`
        ).getTime()
        const dateB = new Date(
          `${b.deal_year}-${String(b.deal_month).padStart(2, '0')}-${String(b.deal_day).padStart(2, '0')}`
        ).getTime()
        return dateA - dateB
      })
      .map((item) => ({
        date: formatDealDate(item),
        price: Number(item.price_krw || 0),
      }))
      .filter((item) => item.price > 0)
  }, [filteredTransactions])

  const roadAddress = formatRoadAddress(complex)
  const jibunAddress = formatJibunAddress(complex)
  const buildText = formatBuildText(complex.build_year)

  return (
    <main className="min-h-screen px-6 py-10">
      <div className="mx-auto max-w-5xl">
        <Link
          href="/"
          className="inline-flex rounded-xl border px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
        >
          ← 목록으로
        </Link>

        <div className="mt-6 rounded-3xl border p-8">
          <h1 className="text-3xl font-bold">
            {complex?.official_name || '단지 상세'}
          </h1>

          <div className="mt-4 space-y-1 text-base text-gray-600">
            {roadAddress && <div>{roadAddress}</div>}
            {jibunAddress && <div>{jibunAddress}</div>}
            {buildText && <div>{buildText}</div>}
          </div>
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border p-4">
            <div className="text-sm text-gray-500">거래건수</div>
            <div className="mt-2 text-2xl font-bold">{dealCount}건</div>
          </div>

          <div className="rounded-2xl border p-4">
            <div className="text-sm text-gray-500">최고가</div>
            <div className="mt-2 text-2xl font-bold text-red-600">
              {maxPrice ? formatKoreanPrice(maxPrice) : '-'}
            </div>
          </div>

          <div className="rounded-2xl border p-4">
            <div className="text-sm text-gray-500">최저가</div>
            <div className="mt-2 text-2xl font-bold">
              {minPrice ? formatKoreanPrice(minPrice) : '-'}
            </div>
          </div>

          <div className="rounded-2xl border p-4">
            <div className="text-sm text-gray-500">최근거래가</div>
            <div className="mt-2 text-2xl font-bold text-orange-500">
              {latestPrice ? formatKoreanPrice(latestPrice) : '-'}
            </div>
          </div>
        </div>

        {areaList.length > 0 && (
          <div className="mt-8 rounded-2xl border p-4">
            <h2 className="text-lg font-semibold">면적 선택</h2>

            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setSelectedArea(null)}
                className={`rounded-full border px-4 py-2 text-sm ${
                  selectedArea === null
                    ? 'border-black bg-black text-white'
                    : 'border-gray-300 bg-white text-gray-700'
                }`}
              >
                전체 ({safeTransactions.length})
              </button>

              {areaList.map(({ area, count }) => (
                <button
                  key={area}
                  type="button"
                  onClick={() => setSelectedArea(area)}
                  className={`rounded-full border px-4 py-2 text-sm ${
                    selectedArea === area
                      ? 'border-black bg-black text-white'
                      : 'border-gray-300 bg-white text-gray-700'
                  }`}
                >
                  {area}㎡ ({count})
                </button>
              ))}
            </div>
          </div>
        )}

        <NaverMap
          name={complex?.official_name || undefined}
          address={roadAddress || undefined}
          areaAddress={jibunAddress || undefined}
        />

        <div className="mt-8 rounded-2xl border p-4">
          <h2 className="text-lg font-semibold">가격 추이</h2>

          {chartData.length <= 1 ? (
            <div className="mt-4 flex h-80 items-center justify-center text-gray-500">
              거래 데이터가 부족해서 추이를 표시하기 어렵습니다.
            </div>
          ) : (
            <div className="mt-4 h-80 min-w-0 min-h-[320px]">
              <PriceChart data={chartData} />
            </div>
          )}
        </div>

        <div className="mt-8 rounded-2xl border p-4">
          <h2 className="text-lg font-semibold">최근 거래 내역</h2>

          <div className="mt-4 grid gap-3">
            {filteredTransactions.map((item, index) => (
              <div
                key={`${item.id || index}-${item.deal_year}-${item.deal_month}-${item.deal_day}`}
                className="rounded-2xl border p-4"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-sm text-gray-500">
                      거래일 {formatDealDate(item)}
                    </div>
                    <div className="mt-2 text-sm text-gray-600">
                      {item.umd_name || item.dong || '-'} · {item.area_m2 ?? '-'}㎡ · {item.floor ?? '-'}층
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm text-gray-500">거래가</div>
                    <div className="mt-1 text-xl font-bold text-orange-500">
                      {item.price_krw ? formatKoreanPrice(Number(item.price_krw)) : '-'}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
